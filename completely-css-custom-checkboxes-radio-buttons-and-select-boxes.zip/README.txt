A Pen created at CodePen.io. You can find this one at https://codepen.io/KenanYusuf/pen/PZKEKd.

 CodePen demo for: http://kyusuf.com/post/completely-css-custom-checkbox-radio-buttons-and-select-boxes